# pegawai

<img src="https://img.shields.io/github/license/ipang-dwi/xdesktop.svg" /> <img src="https://img.shields.io/badge/lab-firstplato.com-red.svg" />

Contoh crud sederhana dengan PHP.

Dengan native PHP

Cara memakai :
- copy semua file ke web folder kamu
- buat database baru dan lakukan import pegawai.sql ke database yang sudah dibuat
- edit file koneksi.php sesuaikan dengan setting database yang dipakai
- coba di browser

Feel free to reach me on :
- https://www.firstplato.com
- https://www.facebook.com/firstplato
- admin@firstplato.com

Bingung, mau tanya-tanya bisa WA di o856 48587 856
