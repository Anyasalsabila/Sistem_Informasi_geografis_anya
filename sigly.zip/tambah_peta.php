<?php 
	session_start();
	if($_SESSION['login']!='login') header('Location: login.php');
	include 'koneksi.php'; 	// include = menambahkan/mengikutkan file, setting koneksi ke database
?>
<?php 
  include 'lib/navbar.php';
?>

  <body>


    <div class="container-fluid">
      <div class="row">
        <div class="col-sm-3 col-md-2 sidebar">
          <ul class="nav nav-sidebar">
            <?php if($_SESSION['level']=='admin'){?>
			<li><a href="user.php">User <span class="sr-only">(current)</span></a></li>
			<?php } ?>
            <li class="active"><a href="#">Peta</a></li>
            <li><a href="diagram.php">Diagram</a></li>
            <li><a href="lokasi.php">Lokasi</a></li>
            </ul>
        </div>
        <div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
          
		  <div class="row">
		  <div class="col-md-6">
		  <div>
			<form class="form-horizontal" action="proses_tambah_peta.php" method="POST">
			  <div class="form-group">
				<label for="nama" class="col-sm-2 control-label">Nama</label>
				<div class="col-sm-10">
				  <input type="text" class="form-control" name="nama" id="nama" placeholder="Masukkan Nama untuk Pegawai baru" required />
				</div>
			  </div>
			  <div class="form-group">
				<label for="Alamat" class="col-sm-2 control-label">Alamat</label>
				<div class="col-sm-10">
				  <input type="text" class="form-control" name="alamat" id="alamat" placeholder="Masukkan Alamat untuk Pegawai baru" required />
				</div>
			  </div>
			  <div class="form-group">
				  <label for="divisi" class="col-sm-2 control-label">Divisi</label>
				  <div class="col-sm-10">
				  <select name="divisi" id="disabledSelect" class="form-control">
					<?php 
						$result = $mysqli->query("select * from divisi");	 
						if($result->num_rows > 0){
							// echo "divisi ada";
							while($row = $result->fetch_assoc()) {
								echo '<option value="'.$row["id_divisi"].'">'.ucfirst($row["divisi"]).'</option>';
							}
						}
					?>
				  </select>
				  </div>
			  </div>
			  <div class="form-group">
				<div class="col-sm-offset-2 col-sm-10">
				  <button type="reset" class="btn btn-danger">Reset</button>
				  <a type="cancel" class="btn btn-warning" href="peta.php">Cancel</a>
				  <button type="submit" class="btn btn-primary">Tambah Data Baru</button>
				</div>
			  </div>
			</form>
		  </div>
		  </div>
		  <div class="col-md-6">
		  </div>
		  </div><!-- row -->
         </div>
        </div>
      </div>
    </div>

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
	<!-- DATA TABES SCRIPT -->
    <script src="js/jquery.dataTables.js" type="text/javascript"></script>
    <script src="js/dataTables.bootstrap.js" type="text/javascript"></script>
	<script src="js/dataTables.tableTools.min.js" type="text/javascript"></script>
    <!-- Just to make our placeholder images work. Don't actually copy the next line! -->
    <script src="js/holder.min.js"></script>
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src="../../assets/js/ie10-viewport-bug-workaround.js"></script>
	<!-- page script -->
    <script type="text/javascript">
      $(function () {
        $("#example1").dataTable();
        $('#example2').dataTable({
          "bPaginate": true,
          "bLengthChange": false,
          "bFilter": false,
          "bSort": true,
          "bInfo": true,
          "bAutoWidth": false
        });
      });
    </script>
  </body>
</html>
